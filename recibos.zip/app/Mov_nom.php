<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mov_nom extends Model
{
    protected $table = 'mov_nom';
}
