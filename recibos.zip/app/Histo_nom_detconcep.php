<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Histo_nom_detconcep extends Model
{
    protected $table = 'histo_nom_detconcep';
}
