<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hist_nom_dettrab extends Model
{
    //
}
