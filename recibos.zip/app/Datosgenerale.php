<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Datosgenerale extends Model
{
    //
    protected $table = 'datosgenerales';
}
