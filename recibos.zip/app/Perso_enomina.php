<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Perso_enomina extends Model
{
    protected $table = 'perso_enomina';
}
