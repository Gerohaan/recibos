@extends('app')



@section('contenido')

<!-- Ingreso de Datos -->
@include('datosgenerales.secciones.ingresoDatos')



@endsection