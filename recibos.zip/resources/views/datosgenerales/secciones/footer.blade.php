<footer class="pt-4 my-md-5 pt-md-5 border-top">
    <div class="row">
     
      <div class="col-lg-4 col-md-4">
        <h5>Caracteristicas</h5>
        <ul class="list-unstyled text-small">
          <li><a class="text-muted" href="#">Flexibilidad</a></li>
          <li><a class="text-muted" href="#">Entorno Amigable</a></li>
          <li><a class="text-muted" href="#">Facilidad</a></li>
          <li><a class="text-muted" href="#">Mejora de Atención</a></li>
        </ul>
      </div>
      <div class="col-lg-4 col-md-4">
        <h5>Opciones</h5>
        <ul class="list-unstyled text-small">
          <li><a class="text-muted" href="#">Perfil del trabajador</a></li>
          <li><a class="text-muted" href="#">Constancia de Trabajo</a></li>
          <li><a class="text-muted" href="#">Recibos de Pago</a></li>
        </ul>
      </div>
      <div class="col-lg-4 col-md-4">
        <h5>Nosotros</h5>
        <ul class="list-unstyled text-small">
          <li><a class="text-muted" href="#">Equipo</a></li>
          <li><a class="text-muted" href="#">Ubicación</a></li>
          <li><a class="text-muted" href="#">Privacidad</a></li>
          <li><a class="text-muted" href="#">Terminos</a></li>
        </ul>
      </div>
      <div align="center" class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
        <small class="d-block mb-3 text-muted"><strong>&copy; 2019 Diseño y Programación: Ing. Pedro Miguel Delgado - Ing. Gerohaan Torrealba.</strong></small>
      </div>
    </div>
</footer>