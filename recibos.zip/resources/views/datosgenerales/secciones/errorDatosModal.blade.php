
<div class="modal fade" id="datosTrabajadorError" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" data-backdrop="static" data-keyboard="false" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Saludos</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
      </div>
      <div class="modal-body">
      <ul class="list-group">
          <li class="list-group-item">
          .
          </li>
      </ul>
      <ul class="list-group">
          <li class="list-group-item">
          .
          </li>
      </ul>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" @click="cerrarModal">Cancelar</button>
        <button type="button" class="btn btn-danger">Consultar</button>
      </div>
    </div>
  </div>
</div>