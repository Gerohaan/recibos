<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
<div class="content">
                    <center>
                    	<img src="<?php echo e(asset('img/logo.png')); ?>" class="img-fluid">
                    </center>
                    <p style="text-align: justify; size: 2px;">Rif: G-20008795-1</p>
                    <table style="font-size: 9px; text-align: center;" width="100%" class="table table-sm">
                    	<thead>
                    		<tr>
                    			<td colspan="4" style="text-align: center;"><h3>Datos del Trabajador</h3></td>
                    		</tr>
                    		<tr>
                    			<th><strong>Codigo y Cedula:</strong></th>
                    			<th><strong>Nombres y Apellidos:</strong></th>
                    			<th><strong>Cargo:</strong></th>
                    			<th><strong>Fecha de Ingreso:</strong></th>
                    		</tr>
                    	</thead>
                    	<tbody>
                    		<tr>
                    			<td>(<?php echo e($datostrab->id_trab); ?>) <?php echo e($datostrab->nacionalidad); ?>-<?php echo e($datostrab->cedula); ?></td>
                    			<td><?php echo e($datostrab->nombre); ?> <?php echo e($datostrab->apellidos); ?></td>
                    			<td><?php echo e($datostrab->cargo); ?></td>
                    			<td><?php echo e(date('d/m/Y', strtotime($datostrab->f_ingAdmPubl))); ?></td>
                    		</tr>
                    		<tr>
                    			<td><strong>Nomina:</strong></td>
                    			<td><?php echo e($datostrab->id_nomina); ?> <?php echo e($datostrab->denominacion); ?> <?php echo e($datostrab->condicion); ?></td>
                    			<td><strong>Dependencia:</strong></td>
                    			<td><?php echo e($datostrab->iddepen); ?> <?php echo e($datostrab->dependencia); ?> </td>
                    		</tr>
                    	</tbody>
                    </table> 
                    <?php
                    	$totaldevengado=0; 
                    ?>
                    		<?php for($i = 0; $i < count($encanominas); $i++): ?>
                    		<table style="font-size: 9px; text-align: center;" width="100%" class="table table-sm">
	                    	<thead>
	                    		<tr style="height: 5px;">
	                    			<td colspan="4" style="text-align: center;"><h5>Nomina</h5></td>
	                    		</tr>
	                    		<tr>
                    			<th style="width: 25%">Descripción</th>
                    			<th style="width: 25%">Cargo</th>
                    			<th style="width: 25%">Denominación</th>
                    			<th style="width: 25%">Forma Pago</th>
                    			</tr>
	                    	</thead>
	                    	<tbody>
    						<tr>
                    			<td><?php echo e($encanominas[$i]['nomina']); ?> <?php echo e($encanominas[$i]['descripcion']); ?></td>
                    			<td><?php echo e($encanominas[$i]['cargo']); ?></td>
                    			<td><?php echo e($encanominas[$i]['denominacion']); ?></td>
                    			<td><?php echo e($encanominas[$i]['idforpago']); ?></td>
                    		</tr>
                    		</tbody>
                    		</table>
                    		<table style="font-size: 9px; text-align: center;" width="100%" class="table table-sm">
                    			<thead>
		                    		<tr>
		                    			<th style="width: 20%">Codigo</th>
		                    			<th style="width: 60%">Descripción</th>
		                    			<th style="width: 10%">Asignación</th>
		                    			<th style="width: 10%">Deducción</th>
		                    		</tr>
		                    	</thead>
		                    	<tbody>
		                    	<?php
								$subtotal_a=0;
								$subtotal_d=0;
								?>
                    			<?php for($j = 0; $j < count($detnominas); $j++): ?>
                    			<?php if( $encanominas[$i]['cod_docu'] == $detnominas[$j]['cod_docum']): ?>
                    				<tr>
		                    			<td><?php echo e($detnominas[$j]['cod_concep']); ?></td>
		                    			<td><?php echo e($detnominas[$j]['descrip_corta']); ?></td>
		                    			<td style="text-align:right;"><?php echo e(number_format($detnominas[$j]['asignacion'], 2, ',', '.')); ?></td>
		                    			<td style="text-align:right;"><?php echo e(number_format($detnominas[$j]['deduccion'], 2, ',', '.')); ?></td>
	                    			</tr>
	                    		<?php
								$subtotal_a=$subtotal_a+($detnominas[$j]['asignacion']*1);
								$subtotal_d=$subtotal_d+($detnominas[$j]['deduccion']*1);
								?>
								<?php endif; ?>
								<?php endfor; ?>
								<?php
								$total=$subtotal_a-$subtotal_d;
								$totaldevengado=$totaldevengado+$total;
								$letras=NumeroALetras\NumeroALetras::convertir($total, 'Bolivares');  
								?>
								</tbody>
								<tfoot>
						            <tr>
						            	<th></th>
						                <th style="text-align:right;">SubTotales</th>
						                <th style="text-align:right;"><?php echo e(number_format($subtotal_a, 2, ',', '.')); ?></th>
						                <th style="text-align:right;"><?php echo e(number_format($subtotal_d, 2, ',', '.')); ?></th>    
						            </tr>
						            <tr>
						                <th style="text-align:right;">Total</th>
						                <th colspan="2"><?php echo e($letras); ?></th>
						                <th style="text-align:right;"><?php echo e(number_format($total, 2, ',', '.')); ?></th>    
						            </tr> 
						            </tfoot>
	                    		</table>   
							<?php endfor; ?>
							<?php 
								$letrasd=NumeroALetras\NumeroALetras::convertir($totaldevengado, 'Bolivares'); 
							?>
							<table style="font-size: 9px; text-align: center;" width="100%" class="table table-sm">
								<tr>
						            <th style="text-align:right;">Total devengado en el periodo</th>
						            <th colspan="2"><?php echo e($letrasd); ?></th>
						            <th style="text-align:right;"><?php echo e(number_format($totaldevengado, 2, ',', '.')); ?></th>    
						        </tr> 
						    </table>  	

</div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\recibos\resources\views/pdf/recibo.blade.php ENDPATH**/ ?>