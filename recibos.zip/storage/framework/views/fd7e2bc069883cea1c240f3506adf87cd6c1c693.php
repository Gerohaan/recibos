<?php $__env->startSection('contenido'); ?>


<div class="card-body">
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
         <div class="row">
            <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">
                <div class="form-group">
                    <h3>Cedula</h3>
                    <?php echo e($request->Cedula); ?>

                </div>
            </div>
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                <div class="form-group">
                    <h3>Nombre y Apellido</h3>
                    <?php echo e($dato->nombre); ?>  <?php echo e($dato->apellidos); ?>

                </div>
            </div>
            <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">
                <div class="form-group">
                    <h3>Fecha de Ingreso</h3>
                    <?php echo e($dato->f_ingInstitucion); ?> 
                </div>
            </div>   
        </div>
        <div class="row">
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                <div class="form-group">
                     <h3>Cargo</h3>
                    <?php echo e($dato->cargo); ?> 
                </div>
            </div>
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                <div class="form-group">
                    <h3>Dependencia</h3>
                    <?php echo e($dato->dependencia); ?> 
                </div>
            </div>  
        </div>
        <div class="card-header">
            <h4 class="my-0 font-weight-normal">Periodo a Consultar <?php echo e($request->MesConsulta); ?>-<?php echo e($request->AnnoConsulta); ?></h4>
        </div>
        <div class="card-header">
            <h4 class="my-0 font-weight-normal">Nominas canceladas en el periodo</h4>
        </div>
        <div class="row">
            <div class="col-6 col-md"> 
            <div class="form-group">
                 <input type="radio" name="opnom" value="<?php echo e($periodo); ?>">MOSTRAR PERIODO COMPLETO<br>  
                 <?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="radio" name="opnom" value="<?php echo e($detalle->cod_docu); ?>"><?php echo e($detalle->detalle); ?><br>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>

        </div>  
        
        <input type="hidden" name="MesConsulta" value="<?php echo e($request->MesConsulta); ?>">
        <input type="hidden" name="MesConsulta" value="<?php echo e($request->AnnoConsulta); ?>">
        <input type="hidden" name="MesConsulta" value="<?php echo e($periodo); ?>">
        <button type="submit" class="btn btn-lg btn-block btn-primary">Generar Recibo</button>
        
       

      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recibos\resources\views/datosgenerales/index2.blade.php ENDPATH**/ ?>