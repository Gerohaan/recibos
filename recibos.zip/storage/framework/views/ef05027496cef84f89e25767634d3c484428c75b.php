<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <meta name="generator" content="">
        <title>Recibos de Pago</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://getbootstrap.com/docs/4.3/examples/pricing/pricing.css">
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
       <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    </head>
    <body>
  <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
  <h5 class="my-0 mr-md-auto font-weight-normal">Sistema de Autogestón de RRHH</h5>
  <nav class="my-2 my-md-0 mr-md-3">
    <?php if(Route::has('login')): ?>
        <div class="top-right links">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/home')); ?>">Home</a>
            <?php else: ?>
        <a href="<?php echo e(route('login')); ?>">Login</a>
                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>">Register</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
  </nav>
  <a class="btn btn-outline-primary" href="#">Ingresar</a>
</div>
<center><img src="<?php echo e(asset('img/logo.png')); ?>" class="img-fluid"></center>
<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h1 class="display-4">Recibo de Pago</h1>
  <p class="lead">Aplicación para la gestión de trabajadores de la Dirección Estadal de Salud Portuguesa.</p>
</div>

<div class="container">
  <div class="card-deck mb-12 text-center">
    <div class="card mb-12 shadow-sm">
      <div class="card-header">
        <h4 class="my-0 font-weight-normal">Datos del Trabajador</h4>
      </div>
      <div class="card-body">
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php echo Form::open(['route' => 'datos.queryii', 'method' => 'POST']); ?>

         <div class="row">
            <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">
                <div class="form-group">
                    <?php echo Form::label('Cedula', 'Cedula'); ?>

                    <?php echo Form::text('Cedula', $request->Cedula, ['class' => 'form-control']); ?>

                </div>
            </div>
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                <div class="form-group">
                    <?php echo Form::label('Name', 'Nombre y Apellido'); ?>

                    <?php echo Form::text('Name', $dato->nombre.' '.$dato->apellidos, ['class' => 'form-control']); ?>

                </div>
            </div>
            <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">
                <div class="form-group">
                    <?php echo Form::label('f_ingInstitucion', 'Fecha de Ingreso'); ?>

                    <?php echo Form::text('f_ingInstitucion', $dato->f_ingInstitucion, ['class' => 'form-control']); ?>

                </div>
            </div>   
        </div>
        <div class="row">
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                <div class="form-group">
                    <?php echo Form::label('Cargo', 'Cargo'); ?>

                    <?php echo Form::text('Cargo', $dato->cargo, ['class' => 'form-control']); ?>

                </div>
            </div>
            <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                <div class="form-group">
                    <?php echo Form::label('Dependencia', 'Dependencia'); ?>

                    <?php echo Form::text('Dependencia', $dato->dependencia, ['class' => 'form-control']); ?>

                </div>
            </div>  
        </div>
        <div class="card-header">
            <h4 class="my-0 font-weight-normal">Periodo a Consultar <?php echo e($request->MesConsulta); ?>-<?php echo e($request->AnnoConsulta); ?></h4>
        </div>
        <div class="card-header">
            <h4 class="my-0 font-weight-normal">Nominas canceladas en el periodo</h4>
        </div>
        <div class="row">
            <div class="col-6 col-md"> 
            <div class="form-group">
                 <input type="radio" name="opnom" value="<?php echo e($periodo); ?>">MOSTRAR PERIODO COMPLETO<br>  
                 <?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="radio" name="opnom" value="<?php echo e($detalle->cod_docu); ?>"><?php echo e($detalle->detalle); ?><br>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>

        </div>  
            <?php echo Form::hidden('MesConsulta', $request->MesConsulta); ?>

            <?php echo Form::hidden('AnnoConsulta', $request->AnnoConsulta); ?>  
            <?php echo Form::hidden('periodo', $periodo); ?>               
            <?php echo Form::submit('Generar Recibo',['class' => 'btn btn-lg btn-block btn-outline-primary']); ?>

        
        <?php echo Form::close(); ?>


      </div>
    </div>
    
  <footer class="pt-4 my-md-5 pt-md-5 border-top">
    <div class="row">
      <div class="col-12 col-md">
        <small class="d-block mb-3 text-muted">&copy; 2019 Diseño y Programación: Ing. Pedro Miguel Delgado</small>
      </div>
      <div class="col-6 col-md">
        <h5>Caracteristicas</h5>
        <ul class="list-unstyled text-small">
          <li><a class="text-muted" href="#">Flexibilidad</a></li>
          <li><a class="text-muted" href="#">Entorno Amigable</a></li>
          <li><a class="text-muted" href="#">Facilidad</a></li>
          <li><a class="text-muted" href="#">Mejora de Atención</a></li>
        </ul>
      </div>
      <div class="col-6 col-md">
        <h5>Opciones</h5>
        <ul class="list-unstyled text-small">
          <li><a class="text-muted" href="#">Perfil del trabajador</a></li>
          <li><a class="text-muted" href="#">Constancia de Trabajo</a></li>
          <li><a class="text-muted" href="#">Recibos de Pago</a></li>
        </ul>
      </div>
      <div class="col-6 col-md">
        <h5>Nosotros</h5>
        <ul class="list-unstyled text-small">
          <li><a class="text-muted" href="#">Equipo</a></li>
          <li><a class="text-muted" href="#">Ubicación</a></li>
          <li><a class="text-muted" href="#">Privacidad</a></li>
          <li><a class="text-muted" href="#">Terminos</a></li>
        </ul>
      </div>
    </div>
  </footer>
</div>
    </body>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
</html>
<?php /**PATH C:\laragon\www\recibos\resources\views/datosgenerales/index2.blade.php ENDPATH**/ ?>