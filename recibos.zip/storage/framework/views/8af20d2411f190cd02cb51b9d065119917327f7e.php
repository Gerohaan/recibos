<?php $__env->startSection('contenido'); ?>

<!-- Ingreso de Datos -->
<?php echo $__env->make('datosgenerales.secciones.ingresoDatos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recibos\resources\views/principal.blade.php ENDPATH**/ ?>