<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
                <h5 class="my-0 mr-md-auto font-weight-normal">Sistema de Autogestón de RRHH</h5>
                    <nav class="my-2 my-md-0 mr-md-3">
                    <?php if(Route::has('login')): ?>
                        <div class="top-right links">
                            <?php if(auth()->guard()->check()): ?>
                                <a href="<?php echo e(url('/home')); ?>">Home</a>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>">Login</a>
                            <?php if(Route::has('register')): ?>
                                    <a href="<?php echo e(route('register')); ?>">Register</a>
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    </nav>
                <a class="btn btn-outline-primary" href="#">Ingresar</a>
</div><?php /**PATH C:\xampp\htdocs\recibos\resources\views/datosgenerales/secciones/login.blade.php ENDPATH**/ ?>