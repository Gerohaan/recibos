<center><img src="<?php echo e(asset('img/logo.png')); ?>" class="img-fluid"></center>

<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h2 class="display-4">Solicitud Trabajador</h2>
  <p class="lead">Aplicación para la gestión de trabajadores de la Dirección Estadal de Salud Portuguesa.</p>
</div>
<?php /**PATH C:\xampp\htdocs\recibos\resources\views/datosgenerales/secciones/header.blade.php ENDPATH**/ ?>